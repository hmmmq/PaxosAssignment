# 运行记录
运行main函数
```text
M1 is starting an election.
M2 is starting an election.
M1 votes for M2
M1 votes for M1
M5 votes for M1
M1 has already voted.
M5 votes for M2
M5 has already voted.
M3 votes for M2
M3 votes for M1
M3 has already voted.
M8 votes for M1
M8 votes for M2
M8 has already voted.
M2 votes for M1
M2 votes for M2
M2 has already voted.
M4 votes for M1
M4 votes for M2
M4 has already voted.
M7 votes for M1
M7 votes for M2
M7 has already voted.
M3 is starting an election.
M6 votes for M1
M6 votes for M2
M6 has already voted.
M1 votes for M3
M1 has already voted.
M5 votes for M3
M5 has already voted.
M3 votes for M3
M3 has already voted.
M8 votes for M3
M8 has already voted.
M9 votes for M1
M2 votes for M3
M4 votes for M3
M9 votes for M2
M2 has already voted.
M9 has already voted.
M4 has already voted.
M1 is elected as council president!
M2 did not get a majority vote.
M7 votes for M3
M7 has already voted.
M6 votes for M3
M6 has already voted.
M9 votes for M3
M9 has already voted.
M3 did not get a majority vote.
Election Results: {M1=7, M2=2}

Process finished with exit code 0

```